const express = require('express');
const router = express.Router();
//IMPORRS PARA AUTENTICACIÓN
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
//GESTION DE ARCHIVOS PDF
const PDFDocument = require('pdfkit');
//GESTION DE ARCHIVOS EXCEL
const xlsx = require('xlsx');




//RUTA PARA REGISTRAR UN NUEVO USUSARIO
router.post('/register', async (req, res) => {
    const { nombre, email, password } = req.body;
    try{
        //VERIFICAR SI EL USUARIO YA EXISTE
        const [userExiste] = await req.db.query('SELECT * FROM usuarios WHERE email = ?', [email]);
        if(userExiste.length>0){
            return res.status(400).json({error: 'El usuario ya existe'})
        }

        //HASHEAR LA CLAVE
        const has = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, has);

        //INSERTAR EL NUEVO USUARIO 
        const sql = 'INSERT INTO usuarios (nombre, email, password) VALUES (?,?,?)';
        const [results] = await req.db.query(sql, [nombre,email, hashedPassword]);

        res.status(201).json({message: 'Usuario creado exitosamente'});
    }catch(err){
        res.status(500).json({message: err.message});
    }
});

//RUTA PARA INICIAR SESIÓN
router.post('/login', async (req, res) => {
   const {email,password} = req.body 
   try {
    //BUSCAR EL USUARIO EN LA BASE DE DATOS
    const [users] = await req.db.query('SELECT * FROM usuarios WHERE email = ?', [email])
    if (users.length === 0) {
        return res.status(400).json({err: 'Credenciales no validas'});        
    }

    const user = users[0];

    //COMPARAR CLAVE 
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
        return res.status(400).json({err: 'Credenciales invalidas'});
    }
    
    //GENERAR Y ASIGNAR UN TOKEN
    const token = jwt.sign({id: user.id}, 'secretkey', {expiresIn: '1h'});
    res.header('Authorization', token).json({message: 'Autenticacion exitosa', token});

   } catch (err) {
    res.status(500).json({message: err.message});
   }
});

const autenticateToken = require('../middleware/auth');
router.use(autenticateToken);

//OBTENER TODOS LOS USUARIOS
router.get('/', async (req, res) => {
    const sql = 'SELECT * FROM usuarios';
    try {
        const [results] = await req.db.query(sql);
        res.json(results);
    } catch (err) {
        return res.status(500).json({error: err.message});        
    }
});

// OBTENER UN USUARIO POR ID 
router.get('/:id', async (req, res) => {
    const { id } = req.params;
    const sql = 'SELECT * FROM usuarios WHERE id = ?';

    try {
        // Ejecutar la consulta de forma asíncrona
        const [results] = await req.db.query(sql, [id]);

        // Verificar si se encontró algún usuario con ese ID
        if (results.length === 0) {
            return res.status(404).json({ error: 'Usuario no encontrado por id' });
        }

        // Devolver los datos del usuario encontrado
        res.json(results[0]);
    } catch (err) {
        // Manejo de errores
        res.status(500).json({ error: err.message });
    }
});


// CREAR UN NUEVO USUARIO
router.post('/', async (req, res) => {
    const { nombre, email } = req.body;
    const sql = 'INSERT INTO usuarios (nombre, email) VALUES (?, ?)';

    try {
        // Ejecutar la consulta de forma asíncrona
        const [results] = await req.db.query(sql, [nombre, email]);

        // Devolver una respuesta con el ID del nuevo usuario
        res.status(201).json({ id: results.insertId, nombre, email });
    } catch (err) {
        // Manejo de errores
        res.status(500).json({ error: err.message });
    }
});


// ACTUALIZAR USUARIO EXISTENTE
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { nombre, email } = req.body;
    const sql = 'UPDATE usuarios SET nombre = ?, email = ? WHERE id = ?';

    try {
        // Ejecutar la actualización de forma asíncrona
        const [results] = await req.db.query(sql, [nombre, email, id]);

        // Verificar si se actualizó algún registro
        if (results.affectedRows === 0) {
            return res.status(404).json({ error: 'Usuario no encontrado para actualizar' });
        }

        // Devolver una respuesta con los datos actualizados
        res.json({ id, nombre, email });
    } catch (err) {
        // Manejo de errores
        res.status(500).json({ error: err.message });
    }
});


//ELIMINAR USUARIO EXISTENTE
router.delete('/:id', async (req, res) => {
    const { id } = req.params;
    const sql = 'DELETE FROM usuarios WHERE id = ?';

    try {
        // Ejecutar la eliminación de forma asíncrona
        const [results] = await req.db.query(sql, [id]);

        // Verificar si se eliminó algún registro
        if (results.affectedRows === 0) {
            return res.status(404).json({ error: 'No se puede Eliminar el Usuario, no se encontro' });
        }

        // Devolver una respuesta confirmando la eliminación
        res.json({ message: 'Usuario eliminado con éxito' });
    } catch (err) {
        // Manejo de errores
        res.status(500).json({ error: err.message });
    }
});

//RUTA PARA DESCARGAR LA INFORMACION DE UN USUARIO EN FORMATO PDF
router.get('/:id/download-pdf', async (req,res) =>{
    const {id} = req.params;

    try {
        //COSULTAR EL USUARIO POR ID
        const [user] = await req.db.query('SELECT * FROM usuarios WHERE id =?', [id]); 
        if (user.length === 0) {
            return res.status(404).json({error: 'No se puede descargar el usuario con formato PDF'});
        }

        //CREAR EL DOCUMENDO PDF
        const doc = new PDFDocument();

        //CONFIGURAR LA RESPUESTA PARA DESCARGAR EL PDF
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=usuario_${id}.pdf`);
        //PIPE DEL DOCUMENTO A LA RESPUESTA HTTP
        doc.pipe(res);

        //AGREGAR CONTENIDO AL DOCUMENTO PDF 
        doc.fontSize(25).text(`Informacion del Usuario ID:${id}`,{align:'center'} );

        doc.moveDown();
        doc.fontSize(14).text(`Nombre: ${user[0].nombre}`);
        doc.text(`Email: ${user[0].email}`);
        doc.text(`Fecha de creacion: ${user[0].fecha_creacion || 'No disponible'}`);

        //FINALIZAR DEL DOCUMENTO
        doc.end();


    } catch (err) {
        res.status(500).json({error : err.message});
    }
});

// RUTA PARA DESCARGAR LA INFORMACIÓN DE TODOS LOS USUARIOS EN FORMATO EXCEL 
router.get('/download-excel', async (req, res) => {
    try {
        // SELECCIONAR TODOS LOS USUARIOS
        const [users] = await req.db.query('SELECT * FROM usuarios');
        if (users.length === 0) {
            return res.status(404).json({ error: 'No hay usuarios registrados' });
        }

        // Crear un nuevo libro de trabajo
        const workbook = xlsx.utils.book_new();
        
        // Crear una hoja de datos con los encabezados
        const data = [
            ["ID", "Nombre", "Email", "Fecha de Creación"], // Encabezados
            ...users.map(user => [user.id, user.nombre, user.email, user.fecha_creacion || 'No disponible']) // Datos de cada usuario
        ];
        
        const worksheet = xlsx.utils.aoa_to_sheet(data);
        
        // Agregar la hoja al libro
        xlsx.utils.book_append_sheet(workbook, worksheet, "Usuarios");

        // Generar el archivo Excel
        const excelBuffer = xlsx.write(workbook, { bookType: "xlsx", type: "buffer" });

        // Establecer cabeceras para la descarga
        res.set({
            'Content-Disposition': 'attachment; filename=usuarios.xlsx',
            'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 
        });

        // Enviar el archivo como respuesta 
        res.send(excelBuffer);
    } catch (err) { 
        res.status(500).json({ error: err.message }); 
    } 
});

module.exports = router;